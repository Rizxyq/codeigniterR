<?php
  
   class User extends CI_Controller {
   
      public function __construct() { 
         parent::__construct(); 
         $this->load->helper(array('form', 'url')); 
         $this->load->library('upload',$config);
        
     } 

      public function index (){
         $err = 0;
         if($this->input->post()){
            $email = $this->input->post('email');
           $password = $this->input->post('password');
           $this->load->model("login_model");
           //echo "sdsd";exit;
           $row = $this->login_model->Login($email,$password); 
          //  $result = $this->db->get_where('login',array('email'=>$email,'password'=>$password,'account_status'=>1))->result_array();
           if($row > 0){
            $err = 0;
            $this->dashboard();
           }else{
            $err = 1;
           }
         }
         $this->load->view('Admin/Login',array('err'=>$err));
     }

     
      public function dashboard(){
         $this->load->view('Admin/Dashboard');
}

     public function section()
     {
      $data = $this->getData();
     $this->load->view('Admin/Section1',array('data'=>$data));
     }

     public function create()
     { 
         if($this->input->post()){
            // $title = $this->input->post('title');
            // $description = $this->input->post('description');
           // echo $title; 
           $data['title'] = $this->input->post('title');
           $data['description'] = $this->input->post('description');
            $this->load->model('login_model');

            $this->login_model->insert($data);
         }
         $this->load->view('Admin/create');
     }

     public function getData()
     {

      $this->load->model('login_model');

      return $data = $this->login_model->getData();
      //print_r($data);exit;
     }

     public function edit($id)
     {
      //echo $id; exit;
    $this->load->model('login_model');
    $data['edit'] = $this->login_model->edituser($id);
   //  $data['edit'] = $this->login_model->edit($this->uri->segement('3'));
   //print_r($data);exit; 
    $this->load->view('Admin/edit',$data);
      }  


  public function updatedit()
  {
    echo $this->uri->segment(3); die;
   $id = $this->uri->segment(3); die;
 if($this->input->post()){
   $data['title'] = $this->input->post('title');
   $data['description'] = $this->input->post('description');
   $this->load->model('login_model');
   // echo $record_id + "  " + $data;die;
   $this->login_model->updateRecord($data, $id);
}
//echo "sdsd";exit;
$this->load->view('Admin/create'); 


}

public function delete($id)
   {
       $this->db->where('id', $id);
       $this->db->delete('create');
       redirect(base_url('create'));
   }

   

      public function sectionget()
      {
         $this->load->view('Admin/section2');
 
      }
   }
       

