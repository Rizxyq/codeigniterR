<?php

class Login_Model extends CI_Model {

    public function __construct()
    {
        $this->load->database();
        $this->load->helper('url');
    }
 

    public function Login($email, $password) {
       
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $query = $this->db->get('login');

        return $query->num_rows();
    }

    public function insert($data){

    //     $data = array(
    //         'title' => $title,
    //         'description' => $description
            
    // );

    //print_r($data); exit;
    
    $this->db->insert('create', $data);
        return true;
    }
   function getData(){
        $query = $this->db->get('create');
        return $query->result();
    }
    public function edituser($id){
       // echo $id; exit;

          // this use only single data
        $this->db->where('id', $id);
        $query = $this->db->get('create');

       // echo "<pre>";
       // print_r($query); exit;

       //recently check data value to last_query
       //echo $this->db->last_query(); exit;
        return $query->row_array();
       // print_r($query); exit;

    }

    // public function get_update($title,$description){
        
    //          $this->db->where('title',$title);
    //     $this->db->where('description', $description);
        
    //     $query = $this->db->update('create');

    //    return $query->num_rows();

    public function getuser($id){
        
        $this->db->where('id',$id);
        $query = $this->db->get('create');
        return $query->row();
    }


    public function update ($data, $id)
     {
        $title = array(
        'title' => $title,
        'description' => $description,       
);
$this->db->where('id', $id);
$this->db->update('create', $data);

//return $query->num_rows();
        //print_r($query); exit;
       
    }        
    
   
    public function delete_news($id)
{
    $this->db->where('id', $id);
    return $this->db->delete('create'); // $this->db->delete('create', array('id' => $id));  
}


    public function sectionc($title , $description){

        $data = array(
            'title' => $title,
            'description' => $description
            
    );

    //print_r($data); exit;
    
    $this->db->insert('getsec', $data);
        return true;
    }
}

